# CSharp_ASPNET source material

This archive is independent. Original specifications, evaluation criteria, test expectations and input evidence are excluded.

Generation status: FINALIZING_CANDIDATE_UI_COVERAGE_INCOMPLETE. Packaging and hash verification do not establish feature completion or runtime acceptance. Consult the accompanying generation record for incomplete scope.

Build: dotnet build "CareerManagement.slnx" -c Release --nologo -p:RestoreLockedMode=true

Required external SDKs, runtimes and configured database are supplied by the execution environment. Generated program and database sources are included; original-spec regeneration is outside this source-only input. Database/deployment instructions are local to this archive.
