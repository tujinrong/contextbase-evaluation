# Access source material

This archive is independent. Original specifications, evaluation criteria, test expectations and input evidence are excluded.

Generation status: GENERATED_VERIFICATION_CANDIDATE_WITH_TECHNICAL_DEVIATION. Packaging and hash verification do not establish feature completion or runtime acceptance. Consult the accompanying generation record for incomplete scope.

Build: Use the included tools/build.py and its local deployment instructions for this source tree.

Required external SDKs, runtimes and configured database are supplied by the execution environment. Generated program and database sources are included; original-spec regeneration is outside this source-only input. Database/deployment instructions are local to this archive.
