# Access → ASP.NET Core 学生管理（配布ソース）

方式IDはAccess-To-CSharp_ASPNET。Access再構築AgentのAR028～030を適用した、PC向けproductionソースのみの独立パッケージ。
2026-10-28のフォルダー改名に対応し、SQL Serverの既存DB名・データは維持している。
.NET SDK 10.0.401系列を使用する。StudentManagement.slnxにはCore/Webのみを登録している。

```powershell
dotnet build StudentManagement.slnx -c Debug
dotnet run --project src/StudentManagement.Web --launch-profile TrainingSql
```

TrainingSqlはローカルSQLEXPRESSの既存DB AccessRebuilderTraining_01a17be7を使用する。
Verification環境で架空のverification-admin主体を使用し、役割はt_app_roleから取得する。
この既存DBを初期化・再作成せず、database/sqlのDDLやseedを再適用しない。
通常配備には接続設定とホスト認証の設定が必要である。

画面は左見出し・右入力欄の表形式とし、日付はカレンダー入力と和暦補助表示を使用する。
原本・正式試験・build・ツール・中間ファイルはこの配布物に含まれない。
