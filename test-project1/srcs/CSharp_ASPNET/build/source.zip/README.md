# CSharp_ASPNET production sources

This archive contains production sources only. Specifications, test code, test fixtures, tools, deployment artifacts and prior verification results are excluded. Packaging does not establish business acceptance.

Use the .NET 10 SDK:

```powershell
dotnet build StudentManagement.Web.csproj -c Release -p:RestoreLockedMode=true
dotnet run --project StudentManagement.Web.csproj --launch-profile SharedTrainingSql
```

SharedTrainingSql uses https://localhost:7241 and Windows authentication to .\SQLEXPRESS / AccessRebuilderTraining_01a17be7. The explicit SharedDatabaseTraining environment and SharedAccess database profile adapt the existing Access-derived database types. The local verification-admin identity is resolved through t_app_role for every request. Only local HTTPS requests are allowed.

Do not run database/001_schema.sql or database/002_seed.sql on the shared training database. Those resources describe an independently initialized Native database. SharedTrainingSql uses the existing shared schema and data without DDL, reset or reseed.

StudentManagement.slnx contains only the production Web, Core and maintenance projects. Compiler output and dependency caches are directed into this extracted archive's .tmp directory by Directory.Build.props. Configuration defaults keep shared training authentication disabled outside the explicit launch profile.
