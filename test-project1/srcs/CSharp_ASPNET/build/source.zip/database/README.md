# SQL Server resources

The supplied schema and seed describe an independently initialized Native application database. Apply them only to a separately approved empty Native database. Configure database roles, encryption and certificate verification for that environment.

The SharedTrainingSql profile instead uses the existing local .\SQLEXPRESS / AccessRebuilderTraining_01a17be7 database with StudentDatabase:Profile=SharedAccess. Do not apply these Native DDL or seed scripts, change database options, reset or reseed that shared database. No additional tables are required.

Specification-driven generators and database integration tests are excluded from this archive.
