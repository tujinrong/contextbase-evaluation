# AS400_RPG source material

This archive is independent. Original specifications, evaluation criteria, test expectations and input evidence are excluded.

Build: IBM i: follow docs/deployment.md and compile cl/BUILD.clle

Required external SDKs, runtimes and configured database are supplied by the execution environment. Generated program and database sources are included; original-spec regeneration is outside this source-only input. Database/deployment instructions are local to this archive.
