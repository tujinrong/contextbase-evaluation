# Vue_CSharpAPI source material

This archive is independent. Original specifications, evaluation criteria, test expectations and input evidence are excluded.

Build: python -X utf8 frontend/build.py publish

Required external SDKs, runtimes and configured database are supplied by the execution environment. Generated program and database sources are included; original-spec regeneration is outside this source-only input. Database/deployment instructions are local to this archive.
