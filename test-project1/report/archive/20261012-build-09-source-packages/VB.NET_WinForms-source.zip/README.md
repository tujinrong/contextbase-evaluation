# VB.NET_WinForms source material

This archive is independent. Original specifications, evaluation criteria, test expectations and input evidence are excluded.

Build: dotnet build StudentManagement.WinForms.slnx -c Release

Required external SDKs, runtimes and configured database are supplied by the execution environment. Generated program and database sources are included; original-spec regeneration is outside this source-only input. Database/deployment instructions are local to this archive.
