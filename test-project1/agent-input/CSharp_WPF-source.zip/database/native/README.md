# Local native database deployment

Build the local SQLCLR assembly and SQL resources with ./database/native/Build-Native.ps1. Apply database/001_schema.sql, database/002_seed.sql, then native/000_sqlclr.sql, native/010_student_api.sql and native/020_master_api.sql in order to a separately approved empty SQL Server 2022 database. The DBA explicitly enables CLR and approves the exact assembly hash. Keep CLR strict security enabled. Configure the application database identity and its local roles. Application writes use the local stored procedures. See INTERFACE.md for the local call contract.
