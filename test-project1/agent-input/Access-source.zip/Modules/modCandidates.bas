Attribute VB_Name = "modCandidates"
Option Explicit
Option Compare Binary
Public Function CandidateClass(ByVal id As Variant) As Object
    Dim tx As New clsUnitOfWork, repo As New clsStudentRepository
    On Error GoTo Failed
    tx.BeginWork: Set repo.Database = tx.Database
    Set CandidateClass = repo.ClassById(PositiveId(id))
    tx.CloseWork
    Exit Function
Failed:
    Dim n As Long, message As String
    n = Err.Number: message = Err.Description
    On Error Resume Next: tx.CloseWork: On Error GoTo 0
    Err.Raise n, , message
End Function
Public Sub RefreshClassChoices(ByVal frm As Access.Form, ByVal originalId As Variant)
    Dim where As String, year As String, grade As String, day As String, activeOnly As Boolean
    where = " WHERE 1=1": day = BusinessDay(UtcNow())
    year = NFKC(Nz(frm!cboSchoolYear, "")): grade = NFKC(Nz(frm!cboGrade, ""))
    If year <> "" Then
        If Not Match(year, "^[0-9]{4}$") Then Err.Raise vbObjectError + 144, , "E-DATE-003"
        where = where & " AND school_year=" & CStr(CLng(year))
    End If
    If grade <> "" Then
        If Not Match(grade, "^[0-9]{2}$") Then Err.Raise vbObjectError + 144, , "E-STU-009"
        where = where & " AND grade_code='" & grade & "'"
    End If
    If frm.Name = "frmStudentEdit" Then
        activeOnly = Nz(frm!cboEnrollmentStatus, "01") = "01" Or Nz(frm!cboEnrollmentStatus, "01") = "02"
        If activeOnly Then where = where & " AND (is_active=True AND valid_from<='" & day & "' AND valid_to>='" & day & "'" & IIf(IsNull(originalId), "", " OR class_id=" & Nz(originalId, 0)) & ")"
    End If
    frm!cboClass.RowSource = "SELECT class_id,CStr(school_year) & ' ' & class_code & ' ' & class_name & IIf(is_active AND valid_from<='" & day & "' AND valid_to>='" & day & "','',' [停止・期間外]') FROM m_class" & where & " ORDER BY school_year,display_order,class_code,class_id"
    frm!cboClass.Requery
End Sub
Public Sub RefreshCodeChoices(ByVal frm As Access.Form, ByVal old As Object)
    Dim pair As Variant, oldValue As Variant, day As String, clause As String
    day = BusinessDay(UtcNow())
    For Each pair In Array(Array("GENDER", "gender_code", "cboGender"), Array("PREFECTURE", "prefecture_code", "cboPrefecture"), Array("ENROLLMENT_STATUS", "enrollment_status_code", "cboEnrollmentStatus"), Array("RELATIONSHIP", "relationship_code", "cboRelationship"))
        oldValue = Null
        If Not old Is Nothing Then oldValue = old(pair(1))
        clause = "c.is_active=True AND k.is_active=True AND c.valid_from<='" & day & "' AND (c.valid_to Is Null OR c.valid_to>='" & day & "')"
        If Not IsNull(oldValue) Then clause = "(" & clause & " OR c.code_value='" & Replace(oldValue, "'", "''") & "')"
        frm.Controls(pair(2)).RowSource = "SELECT c.code_value,c.code_name & IIf(c.is_active AND k.is_active AND c.valid_from<='" & day & "' AND (c.valid_to Is Null OR c.valid_to>='" & day & "'),'',' [停止・期間外]') FROM m_code AS c INNER JOIN m_code_category AS k ON c.category_id=k.category_id WHERE c.category_id='" & pair(0) & "' AND " & clause & " ORDER BY c.display_order,c.code_value"
        frm.Controls(pair(2)).Requery
    Next
End Sub
