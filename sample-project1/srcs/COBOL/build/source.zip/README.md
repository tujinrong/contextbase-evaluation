# COBOL source material

This archive is independent. Original specifications, evaluation criteria, test expectations and input evidence are excluded.

Generation status: REGENERATED. Packaging and hash verification do not establish feature completion or runtime acceptance. Consult the accompanying generation record for incomplete scope.

Build: Windows x64: python -X utf8 build.py --sdk <GnuCOBOL-UCRT-directory> --cc <zig.exe>; then ./Run-Sample.ps1 -RuntimeDirectory <runtime-bin>. Native Console sample, authentication disabled, fixed sample-user/Administrator.

Required external SDKs, runtimes and configured database are supplied by the execution environment. Generated program and database sources are included; original-spec regeneration is outside this source-only input. Database/deployment instructions are local to this archive.
