# Local database deployment

This directory contains the database resources for this project. Use the supplied schema and seed only in a separately approved empty application database. Existing databases require an independently reviewed migration. Configure the local application identity, database driver, encryption and certificate verification in the execution environment. For SQLCLR resources, follow native/README.md if that directory is present. Original-spec regeneration is excluded from this source-only package.
